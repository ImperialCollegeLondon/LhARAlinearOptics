Scratch directory, assumed by some tests and scripts
